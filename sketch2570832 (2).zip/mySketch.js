function setup() {
	createCanvas(400, 300);
	background(200);
}

function draw() {
	background(500)
	
	//hair
	rect(200,190,279,330,80)
	
	rectMode(CENTER);
	fill( 153, 102, 51);
	noStroke(0)
	rect(200,150,160,150,20);
	
	//Face & Ears
	fill(153, 102, 51)
	noStroke(0)
	triangle(205,280,274,220,126,220)
	ellipse(280,170,50)
	ellipse(120,170,50)
	
	//eyes
	fill(500)
	stroke(0)
	fill(500)
	ellipse(160,160,40,55)
	ellipse(236,160,40,55)
	
	//topleft
	fill(102, 51, 0)
	ellipse(164,155,30,)
	//topright
	ellipse(232,154,30)
	
	//mouth
	fill(153, 0, 51)
	ellipse(200,237,60,15)
	line(160,230,200,240)
	line(200,240,240,230)
	
	//nose
	fill(153, 102, 51)
	ellipse(200,198,15,20)
	
	//fringe
	fill(0)
	ellipse(140,84,140,115)
	ellipse(270,84,140,115)
	}