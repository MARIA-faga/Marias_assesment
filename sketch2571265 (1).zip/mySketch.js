
function setup() {
	createCanvas(400, 400)
	
	background(102, 0, 51);
}

function draw() {
	
		//sunset
	fill(255, 204, 0)
	ellipse (200,300,250)
	
	//mountains
	stroke(mouseY,255,255)
	fill(0)
	triangle(0,400,200,200,400,400)
	triangle(-100,400,50,250,300,400)
	triangle(200,400,350,250,500,400)
	triangle(0,400,200,200,400,400)
	
	//The other 2 crosses
	line(50,250,50,200)
	line(30,220,70,220)
	line(350,250,350,200)
	line(330,220,370,220)
	
	//Jesus' Cross
	stroke(2000)
	fill(mouseY,0,0)
	rect(195,55,10,150)
	rect(150,100,100,10)
	
	
	//rain
	fill(2000)
	ellipse(100,100,1,10)
	ellipse(50,50,1,10)
	ellipse(3,10,1,10)
	ellipse(370,250,1,10)
	ellipse(280,100,1,10)
	ellipse(70,70,1,10)
	ellipse(400,1,1,10)
	ellipse(380,50,1,10)
	ellipse(300,35,1,10)
	ellipse(100,200,1,10)
	ellipse(150,10,1,10)
	ellipse(180,30,1,10)
	ellipse(200,230,1,10)
	ellipse(130,5,1,10)
	ellipse(3,200,1,10)
	ellipse(17,175,1,10)
	ellipse(30,150,1,10)
	ellipse(350,180,1,10)
	ellipse(389,160,1,10)

}